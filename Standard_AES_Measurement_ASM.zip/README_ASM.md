# Arduino Uno 用 AES 測定コードのアセンブリ版

添付された `Standard_AES_Measurement.ino` を、従来型 Arduino Uno
（ATmega328P / 16 MHz）用の GNU AVR アセンブリに移植したものです。
**元コードと同じ「初期 AddRoundKey ＋ 第1ラウンド」だけを実行します。**
AES-128 の全10ラウンド暗号化に変更していません。

## 使用するファイル

- `Standard_AES_Measurement_ASM/measurement.S`：AES、xorshift32、鍵の初期化、
  平文生成、繰り返し、バッチ進行、リセット、ログの出力順を実装。
- `Standard_AES_Measurement_ASM/Standard_AES_Measurement_ASM.ino`：Arduino
  の `Serial`、`pinMode`、`digitalWrite`、`delay` を呼ぶための薄い接続部分。
- `reference/Standard_AES_Measurement.ino`：比較用の添付原本。内容は変更していません。

Arduino の標準ライブラリと起動処理は引き続き使用します。UART やタイマーの
ドライバまで独自アセンブリに置き換えた、単独の `.S` ファームウェアではありません。
`.ino` と `.S` の **両方** が必要です。

## Arduino IDE で書き込む

1. `Standard_AES_Measurement_ASM` フォルダーを同名のまま保存します。
2. フォルダー内の `Standard_AES_Measurement_ASM.ino` を Arduino IDE で開きます。
3. ボードを **Arduino Uno**、接続先ポートを使用する Uno に設定します。
4. 検証・書き込みを実行します。`measurement.S` も同じフォルダーからコンパイルされます。
5. シリアルモニタを **115200 baud** に設定し、`S` を送信します。

ファイルの拡張子 `.S` は大文字です。Uno R4 など ATmega328P 以外のボードは対象外です。
Arduino CLI を使う場合は、Arduino AVR Boards を導入後、リポジトリ直下で以下を実行できます。

```sh
arduino-cli compile --fqbn arduino:avr:uno Standard_AES_Measurement_ASM
arduino-cli upload --fqbn arduino:avr:uno --port /dev/ttyACM0 Standard_AES_Measurement_ASM
```

ポート名は実機の接続先に置き換えてください。Arduino IDE/CLI 自体はこのクラウド環境で
実行していません。以下のビルドスクリプトで実際の AVR バイナリを生成・検証しました。

## 維持した動作

| 項目 | 内容 |
|---|---|
| トリガー | D5。AES 実行直前に HIGH、直後に LOW |
| 測定総数 | 5000平文 |
| 1バッチ | 500平文、各平文10回、合計5000トリガー |
| 待機 | 各 AES 実行後10 ms、各平文のログ出力後10 ms |
| コマンド | 大文字 `S` のみ開始・再開。他の受信文字は無視 |
| 乱数 | xorshift32、初期シード12345、各呼び出しの下位8ビットを使用 |
| 再開 | バッチをまたいで乱数状態と平文番号を維持 |
| 完了後 | 次の `S` で平文番号とシードをリセット |
| 鍵・演算 | 原本と同じ2組の鍵、標準 S-Box、同じ状態配列の並び |
| ログ | 原本と同一の英文、番号、ゼロ埋め大文字16進数、CRLF |

最初の結果は以下です。

```text
Trace: 0 PT: 7AAFA0EAD3629838784CBEDF42670BFC State_R1: 1CA175391809342A6C3531929899A195
```

**命令列が変わるため、トリガー幅・実行時間・消費電力波形は原本と同一にはなりません。**
測定区間の前後関係と演算結果は維持しています。Arduino の割り込みは原本同様に有効です。
シリアル入出力のバッファ処理と待機には元と同じ Arduino 標準実装を使用します。

測定条件を変更する場合は `measurement.S` 冒頭の定数を変更します。今回の検証対象は
添付原本と同じ設定です。

## Linux での再ビルド・検証

必要なものは Python 3、AVR GCC/G++、AVR binutils、avr-libc、Arduino AVR Core です。
Debian では `gcc-avr binutils-avr avr-libc arduino-core-avr` に相当します。

```sh
python3 tools/build.py
```

実機用の `build/uno/firmware.elf` と `build/uno/firmware.hex` を生成します。
標準配置以外に導入した場合は次の環境変数で指定できます。

```sh
export AVR_PREFIX=/path/to/toolchain/bin/avr-
export ARDUINO_AVR_ROOT=/path/to/arduino/hardware/arduino/avr
python3 tools/build.py
```

比較検証にはホスト側の GCC と `libsimavr-dev` も必要です。

```sh
python3 tests/run.py
# simavr を独自の場所に導入した場合：
python3 tests/run.py --simavr-prefix /path/to/prefix/usr
```

このスクリプトは以下を行います。

1. 添付原本とアセンブリ版をそれぞれ ATmega328P 向けにコンパイル。
2. 両方を simavr で実行し、5000平文完了とリセット後の500平文を測定。
3. シリアルログ全文と55,000回の D5 パルスで入力・出力の状態16バイトを比較。
4. 独立した Python 実装でも、全5500平文と AES 第1ラウンドの結果を検証。
5. バッチ再開、乱数のリセット、無効文字の無視、60,500回の `delay(10)` 呼び出しを確認。
6. 待機の置換を行わない実機用バイナリでも最初の平文を測定し、10パルスと約10 ms の待機を確認。

長時間の比較用ビルドだけ、`tests/instrument.cpp` が `delay(10)` を記録して待ちを省略します。
`digitalWrite` は記録に加え、実際の Arduino 実装を呼んで D5 も監視します。
通常のビルドにはこのテスト用ファイルをリンクしません。

ビルド済み・検証済みの組み合わせは AVR GCC 14.2.0、Arduino AVR Core 1.8.7、simavr 1.6 です。
物理的な Uno への書き込み、オシロスコープによる実波形の検証は未実施です。
