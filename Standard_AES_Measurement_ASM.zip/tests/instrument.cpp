// Simulation-only wrappers. Production firmware never links this file.
// Count real GPIO calls and requested delays, then skip the wall-clock wait.
#include <Arduino.h>
extern "C" {
volatile uint32_t test_high_count;
volatile uint32_t test_low_count;
volatile uint32_t test_delay_count;
volatile uint32_t test_bad_calls;
volatile uint8_t test_trigger_level;
void __real_digitalWrite(uint8_t, uint8_t);
void __wrap_digitalWrite(uint8_t pin, uint8_t value) {
  if (pin != 5 || value > 1) ++test_bad_calls;
  if (value) {
    if (test_trigger_level) ++test_bad_calls;
    ++test_high_count;
  } else {
    if (!test_trigger_level && test_low_count != 0) ++test_bad_calls;
    ++test_low_count;
  }
  test_trigger_level = value;
  __real_digitalWrite(pin, value);
}
void __wrap_delay(unsigned long ms) {
  ++test_delay_count;
  if (ms != 10 || test_trigger_level) ++test_bad_calls;
}
}
