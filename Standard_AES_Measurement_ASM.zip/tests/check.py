#!/usr/bin/env python3
"""Compare AVR simulations and independently verify every measured state."""
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def gf_mul(a, b):
    result = 0
    for _ in range(8):
        if b & 1:
            result ^= a
        a = ((a << 1) ^ (0x11b if a & 0x80 else 0)) & 255
        b >>= 1
    return result


def sbox(x):
    # Multiplicative inverse + affine transform; no copied lookup table.
    inverse = 0 if x == 0 else 1
    if x:
        for _ in range(254):
            inverse = gf_mul(inverse, x)
    result = inverse ^ 0x63
    for n in range(1, 5):
        result ^= ((inverse << n) | (inverse >> (8 - n))) & 255
    return result


SBOX = [sbox(i) for i in range(256)]
KEY0 = bytes.fromhex("2b7e151628aed2a6abf7158809cf4f3c")
KEY1 = bytes.fromhex("a0fafe1788542cb123a339392a6c7605")


def aes_round(pt):
    sub = [SBOX[a ^ b] for a, b in zip(pt, KEY0)]
    shifted = [sub[4 * ((c + r) % 4) + r] for c in range(4) for r in range(4)]
    mixed = []
    for c in range(4):
        a = shifted[c * 4:c * 4 + 4]
        for r in range(4):
            mixed.append(gf_mul(2, a[r]) ^ gf_mul(3, a[(r + 1) % 4]) ^
                         a[(r + 2) % 4] ^ a[(r + 3) % 4])
    return bytes(a ^ b for a, b in zip(mixed, KEY1))


def check():
    ref = ROOT / "build/reference-test"
    asm = ROOT / "build/asm-test"
    for filename in ("serial.log", "pulses.bin", "stats.json"):
        require((ref / filename).read_bytes() == (asm / filename).read_bytes(),
                f"Original/assembly mismatch: {filename}")
    stats = json.loads((asm / "stats.json").read_text())
    for key, value in {"batches": 11, "commands": 11, "gpio_high": 55000,
                       "gpio_low": 55000, "high_calls": 55000,
                       "low_calls": 55001, "delay_calls": 60500,
                       "bad_calls": 0, "current_trace_index": 500,
                       "ubrr0": 16, "u2x0": 1}.items():
        require(stats[key] == value, f"Unexpected {key}: {stats[key]}")
    require(stats["ddrd"] & 32 and not stats["portd"] & 32,
            "D5 must be configured as output and end low")
    log = (asm / "serial.log").read_bytes()
    lines = re.findall(rb"^Trace: (\d+) PT: ([0-9A-F]{32}) State_R1: ([0-9A-F]{32})\r$",
                       log, re.MULTILINE)
    require(len(lines) == 5500, f"Expected 5500 trace logs, got {len(lines)}")
    require(log.count(b"Batch Complete.") == 10, "Wrong pause count")
    require(log.count(b"Measurements Complete (Reached total traces).\r\n") == 1,
            "Missing final completion")
    require(log.count(b"Resetting state to 0...\r\n") == 1, "Missing restart")
    pulses = (asm / "pulses.bin").read_bytes()
    require(len(pulses) == 55000 * 34, "Wrong number of pulse samples")
    xs = 12345
    for position, (index, plain_hex, result_hex) in enumerate(lines):
        expected_index = position % 5000
        require(int(index) == expected_index, f"Index mismatch at {position}")
        if position == 5000:
            xs = 12345
        expected_pt = bytearray()
        for _ in range(16):
            xs ^= (xs << 13) & 0xffffffff
            xs ^= xs >> 17
            xs ^= (xs << 5) & 0xffffffff
            expected_pt.append(xs & 255)
        require(bytes.fromhex(plain_hex.decode()) == expected_pt,
                f"PRNG mismatch at trace {position}")
        expected_state = aes_round(expected_pt)
        require(bytes.fromhex(result_hex.decode()) == expected_state,
                f"AES mismatch at trace {position}")
        expected_pulses = (b"H" + expected_pt + b"L" + expected_state) * 10
        require(pulses[position * 340:(position + 1) * 340] == expected_pulses,
                f"Input/result changed between repeats at trace {position}")
    require(stats["prng"] == xs, "Final PRNG state mismatch")
    print("PASS: original and assembly serial logs and 55,000 GPIO pulses match")
    print("PASS: 5,500 plaintexts and AES round results independently verified")
    print("PASS: 11 batches, pause/resume, seed restart, ignored commands, "
          "60,500 delay(10) calls")


if __name__ == "__main__":
    check()
