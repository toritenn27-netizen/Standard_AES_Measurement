// Run actual AVR firmware with simavr, including Arduino UART and GPIO.
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sim_avr.h"
#include "sim_elf.h"
#include "sim_io.h"
#include "avr_uart.h"
#include "avr_ioport.h"

typedef struct {
    avr_t *avr;
    avr_irq_t *input;
    FILE *serial, *pulses;
    uint16_t state_address;
    char line[512];
    size_t length;
    unsigned batches, commands, high, low;
    int done, pin_high, smoke;
    avr_cycle_count_t last_low, min_gap;
} context_t;

static uint16_t address(elf_firmware_t *fw, const char *name) {
    for (uint32_t i = 0; i < fw->symbolcount; ++i)
        if (strcmp(fw->symbol[i]->symbol, name) == 0)
            return fw->symbol[i]->addr & 0xffff;
    fprintf(stderr, "Missing firmware symbol: %s\n", name);
    exit(2);
}

static uint32_t read32(avr_t *avr, uint16_t addr) {
    return (uint32_t)avr->data[addr] |
           (uint32_t)avr->data[addr+1] << 8 |
           (uint32_t)avr->data[addr+2] << 16 |
           (uint32_t)avr->data[addr+3] << 24;
}

static void pin_changed(struct avr_irq_t *irq, uint32_t value, void *param) {
    (void)irq;
    context_t *ctx = param;
    int high = value & 1;
    if (high == ctx->pin_high) return;
    ctx->pin_high = high;
    if (high) {
        ++ctx->high;
        if (ctx->last_low) {
            avr_cycle_count_t gap = ctx->avr->cycle - ctx->last_low;
            if (!ctx->min_gap || gap < ctx->min_gap) ctx->min_gap = gap;
        }
    } else {
        ++ctx->low;
        ctx->last_low = ctx->avr->cycle;
    }
    // Every high captures the input state; every low captures the round result.
    fputc(high ? 'H' : 'L', ctx->pulses);
    fwrite(ctx->avr->data + ctx->state_address, 1, 16, ctx->pulses);
}

static void serial_output(struct avr_irq_t *irq, uint32_t value, void *param) {
    (void)irq;
    context_t *ctx = param;
    char ch = (char)value;
    fputc((unsigned char)ch, ctx->serial);
    if (ctx->length + 1 >= sizeof(ctx->line)) {
        fprintf(stderr, "Serial line overflow\n"); exit(2);
    }
    ctx->line[ctx->length++] = ch;
    ctx->line[ctx->length] = 0;
    if (ch != '\n') return;
    if (ctx->smoke && strncmp(ctx->line, "Trace: 0 PT: ", 13) == 0)
        ctx->done = 1;
    int initial = strcmp(ctx->line,
        "Send 'S' to start/resume measurements.\r\n") == 0;
    int pause = strncmp(ctx->line, "Batch Complete.", 15) == 0;
    int complete = strcmp(ctx->line, "Send 'S' to restart from 0.\r\n") == 0;
    if (pause || complete) {
        ++ctx->batches;
        fprintf(stderr, "Completed batch %u\n", ctx->batches);
    }
    if (initial || pause || complete) {
        if (ctx->batches == 11) ctx->done = 1;
        else {
            // Lowercase s, unknown byte and line endings must be ignored.
            const char *input = ctx->commands == 0 ? "xs\r\nS" : "S";
            while (*input) avr_raise_irq(ctx->input, (unsigned char)*input++);
            ++ctx->commands;
        }
    }
    ctx->length = 0;
}

int main(int argc, char **argv) {
    if (argc != 5 && !(argc == 6 && strcmp(argv[5], "--smoke") == 0)) {
        fprintf(stderr, "Usage: %s firmware.elf serial.log pulses.bin stats.json [--smoke]\n", argv[0]);
        return 2;
    }
    elf_firmware_t fw = {0};
    if (elf_read_firmware(argv[1], &fw) != 0) return 2;
    avr_t *avr = avr_make_mcu_by_name("atmega328p");
    if (!avr || avr_init(avr) != 0) return 2;
    avr->frequency = 16000000;
    avr->log = LOG_ERROR;
    avr_load_firmware(avr, &fw);
    uint32_t flags = 0;
    avr_ioctl(avr, AVR_IOCTL_UART_SET_FLAGS('0'), &flags);
    context_t ctx = {.avr = avr, .state_address = address(&fw, "state"),
                     .smoke = argc == 6};
    ctx.serial = fopen(argv[2], "wb");
    ctx.pulses = fopen(argv[3], "wb");
    if (!ctx.serial || !ctx.pulses) return 2;
    ctx.input = avr_io_getirq(avr, AVR_IOCTL_UART_GETIRQ('0'), UART_IRQ_INPUT);
    avr_irq_register_notify(avr_io_getirq(avr, AVR_IOCTL_UART_GETIRQ('0'),
                                        UART_IRQ_OUTPUT), serial_output, &ctx);
    avr_irq_register_notify(avr_io_getirq(avr, AVR_IOCTL_IOPORT_GETIRQ('D'), 5),
                            pin_changed, &ctx);
    while (!ctx.done && avr->cycle < 4000000000ULL) {
        int result = avr_run(avr);
        if (result == cpu_Done || result == cpu_Crashed) {
            fprintf(stderr, "MCU stopped unexpectedly: %d pc=%x\n", result, avr->pc);
            return 1;
        }
    }
    fclose(ctx.serial);
    fclose(ctx.pulses);
    if (!ctx.done) { fprintf(stderr, "Simulation cycle limit exceeded\n"); return 1; }
    FILE *stats = fopen(argv[4], "w");
    if (!stats) return 2;
    if (ctx.smoke) {
        fprintf(stats, "{\"gpio_high\":%u,\"gpio_low\":%u,\"min_gap_cycles\":%llu}\n",
                ctx.high, ctx.low, (unsigned long long)ctx.min_gap);
        fclose(stats);
        avr_terminate(avr);
        if (ctx.high != 10 || ctx.low != 10 || ctx.min_gap < 159936) {
            fprintf(stderr, "Production delay/GPIO smoke test failed\n");
            return 1;
        }
        return 0;
    }
    uint16_t index = address(&fw, "current_trace_index");
    fprintf(stats,
        "{\"batches\":%u,\"commands\":%u,\"gpio_high\":%u,\"gpio_low\":%u,"
        "\"high_calls\":%u,\"low_calls\":%u,\"delay_calls\":%u,"
        "\"bad_calls\":%u,\"current_trace_index\":%u,\"prng\":%u,"
        "\"ddrd\":%u,\"portd\":%u,\"ubrr0\":%u,\"u2x0\":%u}\n",
        ctx.batches, ctx.commands, ctx.high, ctx.low,
        read32(avr, address(&fw, "test_high_count")),
        read32(avr, address(&fw, "test_low_count")),
        read32(avr, address(&fw, "test_delay_count")),
        read32(avr, address(&fw, "test_bad_calls")),
        avr->data[index] | avr->data[index+1] << 8,
        read32(avr, address(&fw, "xorshift_state")),
        avr->data[0x2a], avr->data[0x2b],
        avr->data[0xc4] | avr->data[0xc5] << 8,
        (avr->data[0xc0] >> 1) & 1);
    fclose(stats);
    avr_terminate(avr);
    return 0;
}
