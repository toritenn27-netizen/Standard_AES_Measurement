#!/usr/bin/env python3
"""Build both AVR versions, simulate them, then compare all measurements."""
import argparse
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from build import build, run
from check import check


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--simavr-prefix", type=Path, default=Path("/usr"),
                        help="simavr install prefix containing include/ and lib/")
    args = parser.parse_args()
    output = ROOT / "build"
    output.mkdir(exist_ok=True)
    multiarch = subprocess.check_output(["gcc", "-print-multiarch"], text=True).strip()
    lib = args.simavr_prefix / "lib" / multiarch
    if not lib.is_dir():
        lib = args.simavr_prefix / "lib"
    simulator = output / "simulate"
    run("gcc", "-std=c11", "-Wall", "-Wextra", "-Werror",
        "-I" + str(args.simavr_prefix / "include/simavr"), ROOT / "tests/simulate.c",
        "-L" + str(lib), "-Wl,-rpath," + str(lib), "-lsimavr", "-o", simulator)
    for name, sketch in [("reference-test", ROOT / "reference"),
                         ("asm-test", ROOT / "Standard_AES_Measurement_ASM")]:
        directory = output / name
        elf = build(sketch, directory, test=True)
        run(simulator, elf, directory / "serial.log", directory / "pulses.bin",
            directory / "stats.json")
    check()
    directory = output / "uno"
    elf = build(ROOT / "Standard_AES_Measurement_ASM", directory)
    run(simulator, elf, directory / "serial.log", directory / "pulses.bin",
        directory / "stats.json", "--smoke")
    stats = json.loads((directory / "stats.json").read_text())
    first_line = (directory / "serial.log").read_bytes().split(b"Trace: 0", 1)[1]
    ref_line = (output / "reference-test/serial.log").read_bytes().split(
        b"Trace: 0", 1)[1].split(b"\r\n", 1)[0]
    if first_line.split(b"\r\n", 1)[0] != ref_line:
        raise AssertionError("Production first trace does not match reference")
    print(f"PASS: production firmware, {stats['gpio_high']} pulses, "
          f"minimum gap {stats['min_gap_cycles'] / 16000:.3f} ms")


if __name__ == "__main__":
    main()
