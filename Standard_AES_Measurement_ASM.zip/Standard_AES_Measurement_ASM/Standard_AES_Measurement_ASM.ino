#include <Arduino.h>

// Arduino runtime bridge only. All sketch logic is in measurement.S.
extern "C" {
void measurement_setup();
void measurement_loop();

void fw_serial_begin() { Serial.begin(115200); }
uint8_t fw_serial_available() { return Serial.available() > 0; }
int fw_serial_read() { return Serial.read(); }
void fw_print_flash(const char *text) {
  Serial.print(reinterpret_cast<const __FlashStringHelper *>(text));
}
void fw_print_uint(uint16_t value) { Serial.print(value); }
void fw_print_hex(uint8_t value) { Serial.print(value, HEX); }
void fw_newline() { Serial.println(); }
void fw_trigger_init() {
  pinMode(5, OUTPUT);
  digitalWrite(5, LOW);
}
void fw_trigger_high() { digitalWrite(5, HIGH); }
void fw_trigger_low() { digitalWrite(5, LOW); }
void fw_delay10() { delay(10); }
}

void setup() { measurement_setup(); }
void loop() { measurement_loop(); }
